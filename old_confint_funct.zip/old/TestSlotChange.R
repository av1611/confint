rm (list = ls())


CISlotChange <- setClass("CISlotChange",
                     # contains = "CI",
                     # Define the slots
                     slots = c(mu = "numeric"),
                     # Set the default values for the slots.
                     prototype = list(mu = 0)
                     # Make a function that can test to see if the data is consistent.
                     # This is not called if you have an initialize function defined!
                     # validity = function(object) {
                     #   if(object@alpha < 0 && object@alpha > 1) {
                     #     return("Alpha is out of bounds.")
                     #   }
                     #   return(TRUE)
                     # }
)

setGeneric(name <- "setMu", 
           def <- function(object) { 
             standardGeneric("setMu") 
           } 
)

setMethod(f <- "setMu",
          signature <- "CISlotChange",
          definition <- function(object) {
            object@mu <- object@mu + 10
            return(object)
          }
)

setGeneric(name <- "getMu", 
           def <- function(object) { 
             standardGeneric("getMu") 
           } 
)

setMethod(f <- "getMu",
          signature <- "CISlotChange",
          definition <- function(object) {
            return(object@mu)
          }
)

ci.change.slot <- new("CISlotChange", mu = 1)
getMu(ci.change.slot)
setMu(ci.change.slot)
ci.change.slot <- setMu(ci.change.slot)
setMu(ci.change.slot)
getMu(ci.change.slot)

setMu(ci.change.slot)

ci.change.slot <- setMu(ci.change.slot, mu = 3)
