# install.packages("R6")
library(R6)

# Defining CIR6 class:  ---------------------------------------------
CINormMuR61 <- R6Class("CINormMuR61",
                      inherit = "CIR6",
                      public = list(
                        portable = FALSE,
                        cloneable = FALSE,
                        # CIR6 class fields --------------------------
                        mu    = "numeric",
                        sigma = "numeric",
                        # CIR6 class initialize method ---------------
                        # initialize = function(mu = 0,
                        #                       sigma = 1) {
                        #   self$mu <- mu
                        #   self$sigma <- sigma
                        #   },
                        # CIR6 class methods ---------------------------
                        # mu ---------------------------
                        setMu = function(value) {
                          self$mu <- value
                        },
                        getMu = function() {
                          self$mu
                        },
                        # sigma ---------------------------
                        setSigma = function(value) {
                          self$sigma <- value
                        },
                        getSigma = function() {
                          self$sigma
                        }
                        # compute x ------------------------
                        # setX = function() {
                        #   self$x <- replicate(n = self$getSuperReplicationCount(),
                        #                       expr = replicate(n = self$getSampleSize(),
                        #                                        expr = rnorm(self$getReplicationCount(),
                        #                                                     mean = self$getMu(),
                        #                                                     sd = self$getSigma())))
                        # },
                        # # create arrays to save  ------------------------
                        # createArraysToSave = functon() {
                        #   tQuantile  = -qt(p = self$getAlpha()/2, df = self$getSampleSize() - 1)
                        #   xBar = apply (self$getX(), c(1, 3), mean)
                        #   xCentered = sweep(self$getX(), c(1, 3), xBar) # subtract bar from x
                        #   xCenteredByMu = sweep(self$getX(), c(1, 3), self$getMu()) # subtract mu
                        #   xCenteredSq = xCentered^2 
                        #   # create a column vector with row sums of x.centered.sq
                        #   ss = apply(xCenteredSq, c(1, 3), sum) # 
                        #   # testing - should be close to s2.
                        #   sigmaSqHat = ss / self$getSampleSize()
                        #   marginOfError = tQuantile * sqrt (sigmaSqHat / self$getSampleSize())
                        #   confintLower  = xBar - marginOfError
                        #   confintUpper  = xBar + marginOfError
                        #   confintWidth  = confintUpper - confintLower
                        #   isMuCovered = (self$getMu() < confintUpper & self$getMu() > confintLower)
                        #   sumCovered = apply(isMuCovered, 2, sum)
                        #   coverageRatio = sumCovered / self$getReplicationCount() 
                        #   coverageRatioError = coverageRatio + self$getAlpha() - 1
                        #   arraysToSave <- cbind(as.vector(confintLower),
                        #                         as.vector(confintUpper),
                        #                         as.vector(isMuCovered),
                        #                         as.vector(coverageRatioError),
                        #                         self$getSuperReplicationCount(),
                        #                         self$getReplicationCount(),
                        #                         self$getSampleSize(),
                        #                         self$getAlpha(),
                        #                         self$getSigma(),
                        #                         self$getMu())
                        #   colnames(arraysToSave) <- c("confintLower",
                        #                               "confintUpper",
                        #                               "isMuCovered",
                        #                               "coverageRatioError",
                        #                               "superReplicationCount",
                        #                               "replicationCount",
                        #                               "sampleSize",
                        #                               "alpha",
                        #                               "sigma",
                        #                               "mu")
                        #   self$arraysToSave <- arraysToSave
                        # },
                        # # create paths and names ------------------------
                        # createPathsAndNames = function() {
                        #   paramsInfo <- paste("src", as.character(self$getSuperReplicationCount()),
                        #                       "rc",  as.character(self$getReplicationCount()),
                        #                       "ss",  as.character(self$getSampleSize()),
                        #                       "a",   as.character(self$getAlpha()),
                        #                       "sigma", as.character(self$getSigma()),
                        #                       "mu",  as.character(self$getMu()), sep = "_")
                        #   arraysCsvName = paste0("confintNormMu_", paramsInfo, ".csv")
                        #   arraysCsvPath <- file.path("./", "csv_output", arraysCsvName)
                        #   # Plotting confints
                        #   dir.create(file.path("./", "plots"), showWarnings = FALSE)
                        #   saveImageCIName <- paste0("confintNormMu_", paramsInfo, ".jpeg")
                        #   saveImageCIPath <- file.path("./", "plots", saveImageCIName)
                        #   # Plotting coverage.ratio.error
                        #   # Exporting the plot to a file stored in a "./plots" folder
                        #   dir.create(file.path("./", "plots"), showWarnings = FALSE)
                        #   saveImageCREName <- paste0("coverageRatioErrorNormMu_", paramsInfo, ".jpeg")
                        #   saveImageCREPath<- file.path("./", "plots", saveImageCREName)
                        #   pathsAndNames <- list(arraysCsvPath, saveImageCIPath, saveImageCREPath)
                        #   self$pathsAndNames <- pathsAndNames
                        # },
                        # # save image CI  ------------------------
                        # saveImageCI = function() {
                        #   dir.create(file.path("./", "plots"), showWarnings = FALSE)
                        #   finalInfoLength <- length(self$getArraysToSave())
                        #   sub.title = paste0("src = ", self$getSuperReplicationCount(), ", ",
                        #                      "rc  = ", self$getReplicationCount(),  ", ",
                        #                      "ss  = ", self$getSampleSize(),  ", ", 
                        #                      "a   = ", self$getAlpha(),  ", ",
                        #                      "mu  = ", self$getMu(),  ", ")
                        #   jpeg(self$getPathsAndNames()[2])
                        #   plot (self$getArraysToSave()[, 1], col = "dark blue", type = "l", 
                        #         ylab = "intervals", 
                        #         ylim = range(min(self$getArraysToSave()[, 1]),
                        #                      max(self$getArraysToSave()[, 2])))
                        #   lines (self$getArraysToSave()[, 2], col = "blue")
                        #   abline(h = self$getSigma(), col = "dark gray", lty = 5)
                        #   cl = c("red", "green")
                        #   arrows(1:finalInfoLength, self$getArraysToSave()[, 1][1:finalInfoLength], # confint lower
                        #          1:finalInfoLength, self$getArraysToSave()[, 2][1:finalInfoLength], # confint upper
                        #          angle = 90, code = 0, lwd = 0.1,
                        #          col = cl[self$getArraysToSave()[, 3][1:finalInfoLength] + 1])
                        #   title(main = "Confidence intervals", sub = sub.title, cex.main = 1, cex.sub = 0.7)
                        #   graphics.off()
                        # },
                        # # save image CRE ------------------------
                        # saveImageCRE = function() {
                        #   dir.create(file.path("./", "plots"), showWarnings = FALSE)
                        #   sub.title = paste0("src = ", self$getSuperReplicationCount(), ", ",
                        #                      "rc  = ", self$getReplicationCount(),  ", ",
                        #                      "ss  = ", self$getSampleSize(),  ", ", 
                        #                      "a   = ", self$getAlpha(),  ", ",
                        #                      "mu = ",  self$getMu(),  ", ")
                        #   jpeg(self$getPathsAndNames()[3])
                        #   plot (self$getArraysToSave()[, 4], ylab = "difference",
                        #         ylim = range(min(self$getArraysToSave()[, 4]), 
                        #                      max(self$getArraysToSave()[, 4])))
                        #   title(main = "Difference between supposed and actual coverage probability 
                        #         in a confidence interval for a variance of normal distribution", 
                        #         sub = sub.title,  cex.main = 1, cex.sub = 1)
                        #   graphics.off()
                        # }
                          )
)

# Testing CIR6 class ---------------------------------------------
# ciGeneric <- CIR6$new()
# ciGeneric$getX()
# 
# ciGeneric$setSuperReplicationCount(100)
# ciGeneric$setReplicationCount(100)
# ciGeneric$setSampleSize(100)
# ciGeneric$setX()
# ciGeneric$getX()


