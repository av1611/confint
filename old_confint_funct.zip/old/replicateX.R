replicateX <- function(superReplicationCount,
                       replicationCount,
                       sampleSize,
                       mu,
                       sigma) {
  x = replicate(n = super.replication.count, 
                expr = replicate(n = sample.size, 
                                 expr = rnorm(replication.count, 
                                              mu, 
                                              sigma)))
  
}