rm (list = ls())
if (! require("rstudioapi")) install.packages("rstudioapi")
library(rstudioapi)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
getwd()
# think how to do with if
detach("package:animation", unload=TRUE)

source("confint.sigma.norm.r")
source("confint.bernoulli.r")


confint.sigma.norm(replication.count = 10, 
                   super.replication.count = 10,
                   sample.size = 10, 
                   mu = 0, 
                   sigma = 1,
                   alpha = 0.25)

confint.sigma.norm(replication.count = 50, 
                   super.replication.count = 50,
                   sample.size = 50, 
                   mu = 0, 
                   sigma = 1,
                   alpha = 0.25)


confint.bernoulli(replication.count = 10, 
                   super.replication.count = 10,
                   sample.size = 10, 
                   p = 0.5,
                   alpha = 0.25)

confint.bernoulli(replication.count = 50, 
                   super.replication.count = 50,
                   sample.size = 50, 
                   p = 0.5,
                   alpha = 0.25)





confint.norm.alex(replication.count = 100, sample.size = 10, alpha = 0.25)
confint.norm.alex(replication.count = 20, sample.size = 20)
confint.norm.alex(replication.count = 100, sample.size = 100)
confint.norm.alex(replication.count = 200, sample.size = 200)