# Cleaning out the workspace
rm (list = ls())
# setwd() to the dir where the script have been stored
if (! require("rstudioapi")) install.packages("rstudioapi")
library(rstudioapi)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
# Loading the function
source("CI.R")
source("CINormMu.R")
# source("RandomBernoulli.R")
random1 <- new("CI", src = 10,
               rc   = 100,
               ss   = 100)

random1

random2 <- new("CINormMu", src = 100,
               rc   = 100,
               ss   = 100,
               mu   = 0,
               sigma = 10,
               alpha = 0.5)
random2
doAll(random2, csv_output = T, confint_img = T, cre_img = T)

doAll(random2)


random.bernoulli <- new("RandomBernoulli", SRC = 100,
                        RC   = 100,
                        SS   = 100,
                        P = 0.5,
                        Alpha = 0.5)

doAll(random.bernoulli, csv_output = T, confint_img = T, cre_img = T)

BuildConfInt(random.norm.mu)

# Testing it
random.default <- new ("RandomProcess")
random.default

random1 <- new("RandomProcess", SRC = 10,
               RC   = 100,
               SS   = 100)

BuildConfInt(random1, csv_output = T)
getSRC(random1)
getRC(random1)
getSS(random1)
class(random1)
# Error
# random1 <- new("RandomProcess", SRC = 10,
#                RC   = 100,
#                SS   = 100,
#                Mu = 1,
#                Sigma = 1)
# 
# 
# random1 <- new("RandomProcess", SRC = 1,
#                RC   = 100,
#                SS   = 100)






random.bernoulli <- new("RandomBernoulli", SRC = 100,
                        RC   = 100,
                        SS   = 100,
                        P = 0.5,
                        Alpha = 0.5)

TestOutput(random1)


