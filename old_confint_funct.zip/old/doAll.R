doAll <-  function(object) {
  object$setX()
  
  object$getX()
  object$createArraysToSave()
  object$getArraysToSave()
  object$createPathsAndNames()
  object$getPathsAndNames()
  object$saveCSV()
  object$saveImageCI()
  object$saveImageCRE()
}
