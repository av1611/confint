
# get rid of code duplication
# for saveing jpeg and csv files
# left 2d array, need to flatten
# rigth 2d array, need to flatten
# what is covered - scalar
save.files <- function(
  
)
{

    final.info <- cbind(as.vector(confint.lower),
                      as.vector(confint.upper),
                      as.vector(is.rho.1.covered))
  final.info.length <- length(final.info)
  
  colnames(final.info) <- c("Confint.Lower", "Confint.Upper", "IsSigmaCovered")
  
  # Exporting final.info as CSV into a dedicated dir
  params.info <- paste("src", super.replication.count,
                       "rc",  replication.count,
                       "ss", sample.size,
                       "theta", theta,
                       "sigma", sigma,
                       "mu", mu,
                       "a", alpha, sep = "_")
  dir.create(file.path("./", "csv_output"), showWarnings = FALSE)
  final.info.csv.full.name = paste0("confint.rho.ma1_", params.info, ".csv")
  final.info.csv.path <- file.path("./", "csv_output", final.info.csv.full.name)
  write.csv(final.info, final.info.csv.path)
  
  # Plotting confints
  dir.create(file.path("./", "plots"), showWarnings = FALSE)
  full.name = paste0("confint.rho.ma1_", params.info, ".jpeg")
  plot.path<- file.path("./", "plots", full.name)
  
  jpeg(plot.path)
  plot (final.info[ , 1], col = "dark blue", 
        type = "l",  
        ylab = "intervals", ylim = range(min(final.info[, 1]), max(final.info[, 2])))
  lines (final.info[ , 2], col = "blue")
  abline(h = sigma, col = "dark gray", lty = 5)
  cl = c("red", "green")
  arrows(1:final.info.length, confint.lower[1:final.info.length],
         1:final.info.length, confint.upper[1:final.info.length],
         # length = par("din")[1]/replication.count * 0.5,
         angle = 90, code = 0, lwd = 0.1,
         col = cl[is.rho.1.covered[1:final.info.length] + 1])
  
  main.string = "Confidence intervals for correlation of MA(1) 
  based on Gaussian white noise, using Bartlett's formula"
  sub.title = paste0("src = ", super.replication.count, ", ",
                     "rc = ", replication.count,  ", ",
                     "ss = ", sample.size,  ", ", 
                     "theta = ", theta,  ", ",
                     "sigma = ",  sigma,  ", ",
                     "mu = ", mu, ", ",
                     "alpha = ", alpha, ", ")
  title(main = main.string, sub = sub.title, cex.main = 1, cex.sub = 0.7)
  dev.off()
  
  # Plotting coverage.ratio.error
  # Exporting the plot to a file stored in a "./plots" folder
  dir.create(file.path("./", "plots"), showWarnings = FALSE)
  full.name = paste0("coverage.ratio.error.rho.ma1_", params.info, ".jpeg")
  plot.path<- file.path("./", "plots", full.name)
  jpeg(plot.path)
  plot (coverage.ratio.error, ylab = "difference",
        ylim = range(min(coverage.ratio.error), max(coverage.ratio.error)))
  title(main = "Difference between supposed and actual coverage probability 
        in a confidence interval for a variance of normal distribution", 
        sub = sub.title,  cex.main = 1, cex.sub = 1)
  dev.off()

  
}
  
  