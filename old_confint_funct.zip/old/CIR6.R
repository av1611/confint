# install.packages("R6")
library(R6)

# Defining CIR6 class:  ---------------------------------------------
CIR6 <- R6Class(
  classname = "CIR6",
  public = list(
    portable = FALSE,
    cloneable = FALSE,
    
    # CIR6 class fields ---------------------------------------------
    superReplicationCount = "numeric",
    replicationCount      = "numeric",
    sampleSize            = "numeric",
    alpha = "numeric",
    x     = "array",
    arraysToSave  = "array",
    pathsAndNames = "list",
    CRE = "array",
    
    # CIR6 class initialize method ---------------------------------------------
    initialize = function(superReplicationCount = 3,
                          replicationCount = 4,
                          sampleSize = 5,
                          alpha = 0.05,
                          x = array(0, dim =  rep(0, 3)),
                          arraysToSave = array(0, dim = rep(0, 10)),
                          pathsAndNames = list("", "", ""),
                          CRE = array(0, dim =  rep(0, 3))) {
      self$superReplicationCount <- superReplicationCount
      self$replicationCount <- replicationCount
      self$sampleSize <- sampleSize
      self$alpha <- alpha
      self$x <- x
      self$arraysToSave <- arraysToSave
      self$pathsAndNames <- pathsAndNames
      self$CRE <- CRE
    },
    
    # CIR6 class methods ---------------------------------------------
    setSuperReplicationCount = function(value) {
      self$superReplicationCount <- value
    },
    getSuperReplicationCount = function() {
      self$superReplicationCount
    },
    setReplicationCount = function(value) {
      self$replicationCount <- value
    },
    getReplicationCount = function() {
      self$replicationCount
    },
    setSampleSize = function(value) {
      self$sampleSize <- value
    },
    getSampleSize = function() {
      self$sampleSize
    },
    setAlpha = function(value) {
      self$alpha <- value
    },
    getAlpha = function() {
      self$alpha
    },
    setX = function() {
      
    },
    getX = function() {
      self$x
    },
    createArraysToSave = function() {
      
    },
    getArraysToSave = function() {
      self$arraysToSave
    },
    getCRE = function() {
      self$CRE
    },
    createPathsAndNames = function() {
      
    },
    getPathsAndNames = function() {
      self$pathsAndNames
    },
    saveCSV = function() {
      dir.create(file.path("./", "csv_output"), showWarnings = FALSE)
      write.csv(x = self$getArraysToSave(),
                file = as.character(self$getPathsAndNames()[1]))
    },
    saveImageCI = function() {
      
    },
    saveImageCRE = function() {
      
    },
    doAll = function() {
      self$setX()
      self$createArraysToSave()
      self$createPathsAndNames()
      self$saveCSV()
      self$saveImageCI()
      self$saveImageCRE()
    }
  )
)
