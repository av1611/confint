rm (list = ls())
# setwd() to the dir where the script have been stored
if (! require("rstudioapi")) install.packages("rstudioapi")
library(rstudioapi)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# install.packages("R6")
library(R6)

# Defining CIR6 class:  ---------------------------------------------
CIR6 <- R6Class("CIR6",
                public = list(
                  portable = FALSE,
                  cloneable = FALSE,
                  
# CIR6 class fields ---------------------------------------------
                  superReplicationCount = "numeric",
                  replicationCount      = "numeric",
                  sampleSize            = "numeric",
                  mu    = "numeric",
                  sigma = "numeric",
                  alpha = "numeric",
                  x     = "array",
                  arraysToSave  = "array",
                  pathsAndNames = "list",
                  CRE = "array",

# CIR6 class initialize method ---------------------------------------------  
                  initialize = function(superReplicationCount = 3,
                                        replicationCount = 4,
                                        sampleSize = 5,
                                        mu = 0,
                                        sigma = 1,
                                        alpha = 0.05,
                                        x = array(0, dim =  rep(0, 3)),
                                        arraysToSave = array(0, dim = rep(0, 10)),
                                        pathsAndNames = list("a", "b", "c"),
                                        CRE = array(0, dim =  rep(0, 3))) {
                    self$superReplicationCount <- superReplicationCount
                    self$replicationCount <- replicationCount
                    self$sampleSize <- sampleSize
                    self$mu <- mu
                    self$sigma <- sigma
                    self$alpha <- alpha
                    self$x <- x
                    self$arraysToSave <- arraysToSave
                    self$pathsAndNames <- pathsAndNames
                    },

# CIR6 class methods ---------------------------------------------    
                  setSuperReplicationCount = function(value) {
                    self$superReplicationCount <- value
                    },
                  getSuperReplicationCount = function() {
                    self$superReplicationCount
                    },
                  setReplicationCount = function(value) {
                    self$replicationCount <- value
                    },
                  getReplicationCount = function() {
                    self$replicationCount
                    },
                  setSampleSize = function(value) {
                    self$sampleSize <- value
                    },
                  getSampleSize = function() {
                    self$sampleSize
                    },
                  setMu = function(value) {
                    self$mu <- value
                    },
                  getMu = function() {
                    self$mu
                    },
                  setSigma = function(value) {
                    self$sigma <- value
                    },
                  getSigma = function() {
                    self$sigma
                    },
                  setAlpha = function(value) {
                    self$alpha <- value
                    },
                  getAlpha = function() {
                    self$alpha
                    },
                  setX = function() {
                    self$x <- replicate(
                      n = self$getSuperReplicationCount(),
                      expr = replicate(n = self$getSampleSize(),
                                       expr = rnorm(self$getReplicationCount(),
                                                    mean = self$getMu(),
                                                    sd = self$getSigma())))
                    },
                  getX = function() {
                    self$x
                    },
                  createArraysToSave = function() {
                    tQuantile  = -qt(p = self$getAlpha()/2, df = self$getSampleSize() - 1)
                    xBar = apply(self$getX(), c(1, 3), mean)
                    xCentered = sweep(self$getX(), c(1, 3), xBar) # subtract bar from x
                    xCenteredByMu = sweep(self$getX(), c(1, 3), self$getMu()) # subtract mu
                    xCenteredSq = xCentered^2 
                    # create a column vector with row sums of x.centered.sq
                    ss = apply(xCenteredSq, c(1, 3), sum) # 
                    # testing - should be close to s2.
                    sigmaSqHat = ss / self$getSampleSize()
                    marginOfError = tQuantile * sqrt (sigmaSqHat / self$getSampleSize())
                    confintLower  = xBar - marginOfError
                    confintUpper  = xBar + marginOfError
                    confintWidth  = confintUpper - confintLower
                    isMuCovered = (self$getMu() < confintUpper & self$getMu() > confintLower)
                    sumCovered = apply(isMuCovered, 2, sum)
                    coverageRatio = sumCovered / self$getReplicationCount() 
                    coverageRatioError = coverageRatio + self$getAlpha() - 1
                    # assigning CRE for CRE plot
                    self$CRE <- coverageRatioError
                    arraysToSave <- cbind(as.vector(confintLower),
                                          as.vector(confintUpper),
                                          as.vector(isMuCovered),
                                          as.vector(coverageRatioError),
                                          self$getSuperReplicationCount(),
                                          self$getReplicationCount(),
                                          self$getSampleSize(),
                                          self$getAlpha(),
                                          self$getSigma(),
                                          self$getMu())
                    colnames(arraysToSave) <- c("confintLower",
                                                "confintUpper",
                                                "isMuCovered",
                                                "coverageRatioError",
                                                "superReplicationCount",
                                                "replicationCount",
                                                "sampleSize",
                                                "alpha",
                                                "sigma",
                                                "mu")
                    self$arraysToSave <- arraysToSave
                    },
                    getArraysToSave = function() {
                      self$arraysToSave
                    },
                    # setCRE = function(value) {
                    #   self$CRE <- value
                    #   },
                    getCRE = function() {
                      self$CRE
                      },
                    createPathsAndNames = function() {
                      paramsInfo <- paste("src", as.character(self$getSuperReplicationCount()),
                                          "rc",  as.character(self$getReplicationCount()),
                                          "ss",  as.character(self$getSampleSize()),
                                          "a",   as.character(self$getAlpha()),
                                          "sigma", as.character(self$getSigma()),
                                          "mu",  as.character(self$getMu()), sep = "_")
                      # sub.title <- paste0("src = ",  self$getSuperReplicationCount, ", ",
                      #                    "rc  = ",   self$getReplicationCount,  ", ",
                      #                    "ss  = ",   self$getSampleSize,  ", ", 
                      #                    "a   = ",   self$getAlpha,  ", ",
                      #                    "sigma = ", self$getSigma, ", ",
                      #                    "mu",       self$getMu, ", ")
                      arraysCsvName = paste0("confintNormMu_", paramsInfo, ".csv")
                      arraysCsvPath <- file.path("./", "csv_output", arraysCsvName)
                      # Plotting confints
                      dir.create(file.path("./", "plots"), showWarnings = FALSE)
                      saveImageCIName <- paste0("confintNormMu_", paramsInfo, ".jpeg")
                      saveImageCIPath <- file.path("./", "plots", saveImageCIName)
                      # Plotting coverage.ratio.error
                      # Exporting the plot to a file stored in a "./plots" folder
                      dir.create(file.path("./", "plots"), showWarnings = FALSE)
                      saveImageCREName <- paste0("coverageRatioErrorNormMu_", paramsInfo, ".jpeg")
                      saveImageCREPath<- file.path("./", "plots", saveImageCREName)
                      pathsAndNames <- list(arraysCsvPath, saveImageCIPath, saveImageCREPath)
                      self$pathsAndNames <- pathsAndNames
                      },
                    getPathsAndNames = function() {
                      self$pathsAndNames
                      },
                    saveCSV = function() {
                      dir.create(file.path("./", "csv_output"), showWarnings = FALSE)
                      write.csv(x = self$getArraysToSave(), 
                                file = as.character(self$getPathsAndNames()[1]))
                      },
                    saveImageCI = function() {
                      dir.create(file.path("./", "plots"), showWarnings = FALSE)
                      finalInfoLength <- length(self$getArraysToSave())
                      sub.title = paste0("src = ", self$getSuperReplicationCount(), ", ",
                                         "rc  = ", self$getReplicationCount(),  ", ",
                                         "ss  = ", self$getSampleSize(),  ", ", 
                                         "a   = ", self$getAlpha(),  ", ",
                                         "mu = ", self$getMu(),  ", ")
                      
                      jpeg(self$getPathsAndNames()[2])
                      plot (self$getArraysToSave()[, 1], col = "dark blue", 
                            type = "l",  
                            ylab = "intervals", ylim = range(min(self$getArraysToSave()[, 1]), 
                                                             max(self$getArraysToSave()[, 2])))
                      lines (self$getArraysToSave()[, 2], col = "blue")
                      abline(h = self$getSigma(), col = "dark gray", lty = 5)
                      cl = c("red", "green")
                      arrows(1:finalInfoLength, self$getArraysToSave()[, 1][1:finalInfoLength], # confint lower
                             1:finalInfoLength, self$getArraysToSave()[, 2][1:finalInfoLength], # confint upper
                             angle = 90, code = 0, lwd = 0.1,
                             col = cl[self$getArraysToSave()[, 3][1:finalInfoLength] + 1])
                      title(main = "Confidence intervals", sub = sub.title, cex.main = 1, cex.sub = 0.7)
                      graphics.off()
                      },
                    saveImageCRE = function() {
                      dir.create(file.path("./", "plots"), showWarnings = FALSE)
                      sub.title = paste0("src = ", self$getSuperReplicationCount(), ", ",
                                         "rc  = ", self$getReplicationCount(),  ", ",
                                         "ss  = ", self$getSampleSize(),  ", ", 
                                         "a   = ", self$getAlpha(),  ", ",
                                         "mu = ",  self$getMu(),  ", ")
                      jpeg(self$getPathsAndNames()[3])
                      plot (self$getCRE(), ylab = "difference",
                            ylim = range(min(self$getCRE()), 
                                         max(self$getCRE())))
                      title(main = "Difference between supposed and actual coverage probability 
                            in a confidence interval for a variance of normal distribution", 
                            sub = sub.title,  cex.main = 1, cex.sub = 1)
                      graphics.off()
                    },
                    doAll = function() {
                      # Set X
                       self$x <- replicate(
                        n = self$getSuperReplicationCount(),
                        expr = replicate(n = self$getSampleSize(),
                                         expr = rnorm(self$getReplicationCount(),
                                                      mean = self$getMu(),
                                                      sd = self$getSigma())))
                    getX = function() {
                      self$x
                    },
                    createArraysToSave = function() {
                      tQuantile  = -qt(p = self$getAlpha()/2, df = self$getSampleSize() - 1)
                      xBar = apply(self$getX(), c(1, 3), mean)
                      xCentered = sweep(self$getX(), c(1, 3), xBar) # subtract bar from x
                      xCenteredByMu = sweep(self$getX(), c(1, 3), self$getMu()) # subtract mu
                      xCenteredSq = xCentered^2 
                      # create a column vector with row sums of x.centered.sq
                      ss = apply(xCenteredSq, c(1, 3), sum) # 
                      # testing - should be close to s2.
                      sigmaSqHat = ss / self$getSampleSize()
                      marginOfError = tQuantile * sqrt (sigmaSqHat / self$getSampleSize())
                      confintLower  = xBar - marginOfError
                      confintUpper  = xBar + marginOfError
                      confintWidth  = confintUpper - confintLower
                      isMuCovered = (self$getMu() < confintUpper & self$getMu() > confintLower)
                      sumCovered = apply(isMuCovered, 2, sum)
                      coverageRatio = sumCovered / self$getReplicationCount() 
                      coverageRatioError = coverageRatio + self$getAlpha() - 1
                      # assigning CRE for CRE plot
                      self$CRE <- coverageRatioError
                      arraysToSave <- cbind(as.vector(confintLower),
                                            as.vector(confintUpper),
                                            as.vector(isMuCovered),
                                            as.vector(coverageRatioError),
                                            self$getSuperReplicationCount(),
                                            self$getReplicationCount(),
                                            self$getSampleSize(),
                                            self$getAlpha(),
                                            self$getSigma(),
                                            self$getMu())
                      colnames(arraysToSave) <- c("confintLower",
                                                  "confintUpper",
                                                  "isMuCovered",
                                                  "coverageRatioError",
                                                  "superReplicationCount",
                                                  "replicationCount",
                                                  "sampleSize",
                                                  "alpha",
                                                  "sigma",
                                                  "mu")
                      self$arraysToSave <- arraysToSave
                    },
                    getArraysToSave = function() {
                      self$arraysToSave
                    },
                    # setCRE = function(value) {
                    #   self$CRE <- value
                    #   },
                    getCRE = function() {
                      self$CRE
                    },
                    createPathsAndNames = function() {
                      paramsInfo <- paste("src", as.character(self$getSuperReplicationCount()),
                                          "rc",  as.character(self$getReplicationCount()),
                                          "ss",  as.character(self$getSampleSize()),
                                          "a",   as.character(self$getAlpha()),
                                          "sigma", as.character(self$getSigma()),
                                          "mu",  as.character(self$getMu()), sep = "_")
                      # sub.title <- paste0("src = ",  self$getSuperReplicationCount, ", ",
                      #                    "rc  = ",   self$getReplicationCount,  ", ",
                      #                    "ss  = ",   self$getSampleSize,  ", ", 
                      #                    "a   = ",   self$getAlpha,  ", ",
                      #                    "sigma = ", self$getSigma, ", ",
                      #                    "mu",       self$getMu, ", ")
                      arraysCsvName = paste0("confintNormMu_", paramsInfo, ".csv")
                      arraysCsvPath <- file.path("./", "csv_output", arraysCsvName)
                      # Plotting confints
                      dir.create(file.path("./", "plots"), showWarnings = FALSE)
                      saveImageCIName <- paste0("confintNormMu_", paramsInfo, ".jpeg")
                      saveImageCIPath <- file.path("./", "plots", saveImageCIName)
                      # Plotting coverage.ratio.error
                      # Exporting the plot to a file stored in a "./plots" folder
                      dir.create(file.path("./", "plots"), showWarnings = FALSE)
                      saveImageCREName <- paste0("coverageRatioErrorNormMu_", paramsInfo, ".jpeg")
                      saveImageCREPath<- file.path("./", "plots", saveImageCREName)
                      pathsAndNames <- list(arraysCsvPath, saveImageCIPath, saveImageCREPath)
                      self$pathsAndNames <- pathsAndNames
                    },
                    getPathsAndNames = function() {
                      self$pathsAndNames
                    },
                    saveCSV = function() {
                      dir.create(file.path("./", "csv_output"), showWarnings = FALSE)
                      write.csv(x = self$getArraysToSave(), 
                                file = as.character(self$getPathsAndNames()[1]))

                      # Save Image CI
                      dir.create(file.path("./", "plots"), showWarnings = FALSE)
                      finalInfoLength <- length(self$getArraysToSave())
                      sub.title = paste0("src = ", self$getSuperReplicationCount(), ", ",
                                         "rc  = ", self$getReplicationCount(),  ", ",
                                         "ss  = ", self$getSampleSize(),  ", ", 
                                         "a   = ", self$getAlpha(),  ", ",
                                         "mu = ", self$getMu(),  ", ")
                      
                      jpeg(self$getPathsAndNames()[2])
                      plot (self$getArraysToSave()[, 1], col = "dark blue", 
                            type = "l",  
                            ylab = "intervals", ylim = range(min(self$getArraysToSave()[, 1]), 
                                                             max(self$getArraysToSave()[, 2])))
                      lines (self$getArraysToSave()[, 2], col = "blue")
                      abline(h = self$getSigma(), col = "dark gray", lty = 5)
                      cl = c("red", "green")
                      arrows(1:finalInfoLength, self$getArraysToSave()[, 1][1:finalInfoLength], # confint lower
                             1:finalInfoLength, self$getArraysToSave()[, 2][1:finalInfoLength], # confint upper
                             angle = 90, code = 0, lwd = 0.1,
                             col = cl[self$getArraysToSave()[, 3][1:finalInfoLength] + 1])
                      title(main = "Confidence intervals", sub = sub.title, cex.main = 1, cex.sub = 0.7)
                      graphics.off()
                      
                      # Save Image CRE
                      sub.title = paste0("src = ", self$getSuperReplicationCount(), ", ",
                                         "rc  = ", self$getReplicationCount(),  ", ",
                                         "ss  = ", self$getSampleSize(),  ", ", 
                                         "a   = ", self$getAlpha(),  ", ",
                                         "mu = ",  self$getMu(),  ", ")
                      jpeg(self$getPathsAndNames()[3])
                      plot (self$getCRE(), ylab = "difference",
                            ylim = range(min(self$getCRE()), 
                                         max(self$getCRE())))
                      title(main = "Difference between supposed and actual coverage probability 
                            in a confidence interval for a variance of normal distribution", 
                            sub = sub.title,  cex.main = 1, cex.sub = 1)
                      graphics.off()
                      
                      }
              )
        )

# Testing CIR6 class ---------------------------------------------
ciGeneric <- CIR6$new(
  superReplicationCount = 10,
  replicationCount = 15,
  sampleSize = 20)
ciGeneric
ciGeneric$setX()
ciGeneric$getX()
ciGeneric$createArraysToSave()
ciGeneric$getArraysToSave()

ciGeneric$createPathsAndNames()
ciGeneric$getPathsAndNames()

ciGeneric$saveCSV()
ciGeneric$saveImageCI()
ciGeneric$saveImageCRE()
ciGeneric$doAll()
